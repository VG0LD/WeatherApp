class ApiKeys {
  static const String weatherApiKey = 'efbb55481644baf6ff92e609072dd9c8';
}
const String apiKey = 'efbb55481644baf6ff92e609072dd9c8';
